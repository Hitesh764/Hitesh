var containers = document.querySelectorAll('.container');
var items = document.querySelectorAll('.item');
var resetButton = document.querySelector('.reset-button');

//  event listeners for drag events
items.forEach(function(item) {
  item.addEventListener('dragstart', dragStart);
  item.addEventListener('dragend', dragEnd);
});

containers.forEach(function(container) {
  container.addEventListener('dragover', dragOver);
  container.addEventListener('dragenter', dragEnter);
  container.addEventListener('dragleave', dragLeave);
  container.addEventListener('drop', dragDrop);
});

// Drag functions
function dragStart(e) {
  this.classList.add('dragging');
}

function dragEnd(e) {
  this.classList.remove('dragging');
}

function dragOver(e) {
  e.preventDefault();
}

function dragEnter(e) {
  e.preventDefault();
  this.classList.add('highlight');
}

function dragLeave() {
  this.classList.remove('highlight');
}

function dragDrop(e) {
  this.classList.remove('highlight');
  var draggedItem = document.querySelector('.dragging');
  this.appendChild(draggedItem);
  draggedItem.classList.add('success');
}

// Reset function
function resetContainers() {
  var container1 = document.querySelector('#container1');
  var container2 = document.querySelector('#container2');

  // Clear container 2
  while (container2.firstChild) {
    container2.removeChild(container2.firstChild);
  }

  // Reset container 1
  container1.innerHTML = `
    <div class="item" draggable="true">Item 1</div>
    <div class="item" draggable="true">Item 2</div>
    <div class="item" draggable="true">Item 3</div>
  `;

  // Add event listeners for reset items
  var resetItems = container1.querySelectorAll('.item');
  resetItems.forEach(function(item) {
    item.addEventListener('dragstart', dragStart);
    item.addEventListener('dragend', dragEnd);
  });
}
